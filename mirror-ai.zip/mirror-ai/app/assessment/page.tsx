"use client";
import { useState } from "react";
import Link from "next/link";
import { QUESTIONS, score, archetype } from "@/lib/dna";
const label = (s: string) => s.replace(/_/g, " ");
export default function Assessment() {
  const [a, setA] = useState<number[]>([]);
  if (a.length < QUESTIONS.length) {
    const [, q, c] = QUESTIONS[a.length];
    return <div className="card space-y-3">
      <progress className="w-full accent-violet-500" value={a.length} max={20} />
      <p className="text-sm text-slate-400">Question {a.length + 1} of 20</p><h1 className="text-xl">{q}</h1>
      {c.split("|").map((x, i) => <button key={x} className="ghost block w-full" onClick={() => {
        const next = [...a, i]; setA(next);
        if (next.length === 20) try { localStorage.setItem("dna", JSON.stringify({ answers: next, profile: score(next) })); } catch {}
      }}>{x}</button>)}
      {a.length > 0 && <button className="text-sm underline" onClick={() => setA(a.slice(0, -1))}>Back</button>}
    </div>;
  }
  const p = score(a), sorted = Object.entries(p).sort((x, y) => y[1] - x[1]);
  return <div className="card space-y-3"><h1 className="text-2xl">Your Decision DNA: {archetype(p)}</h1>
    {sorted.map(([k, v]) => <div key={k}><div className="flex justify-between capitalize"><span>{label(k)}</span><span>{v}%</span></div><div className="h-2 rounded bg-white/10"><div className="h-2 rounded bg-gradient-to-r from-blue-500 to-violet-500" style={{ width: `${v}%` }} /></div></div>)}
    <p>Strongest tendencies: {sorted.slice(0, 2).map(x => label(x[0])).join(", ")}.</p>
    <p>Possible blind spots (lowest scores): {sorted.slice(-2).map(x => label(x[0])).join(", ")}.</p>
    <p className="text-xs text-slate-400">This profile is an AI-generated reflection based on your answers, not a psychological diagnosis. Scores come from a simple scoring rule.</p>
    <Link className="btn" href="/mirror">Build My Mirror</Link></div>;
}
