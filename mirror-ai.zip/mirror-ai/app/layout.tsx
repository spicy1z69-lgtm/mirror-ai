import "./globals.css";
import Link from "next/link";
export const metadata = { title: "MIRROR AI", description: "How would I probably decide?" };
export default function Layout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>
    <nav className="mx-auto flex max-w-3xl justify-between p-5"><Link href="/" className="font-semibold tracking-widest">MIRROR AI</Link>
    <span className="flex gap-4 text-sm"><Link href="/assessment">Decision DNA</Link><Link href="/mirror">My Mirror</Link></span></nav>
    <main className="mx-auto max-w-3xl space-y-5 p-5">{children}</main>
    <footer className="p-6 text-center text-xs text-slate-400">Predictions are probabilistic AI reflections, not facts, therapy or diagnosis.</footer>
  </body></html>;
}
