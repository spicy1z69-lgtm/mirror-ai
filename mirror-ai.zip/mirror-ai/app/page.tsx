import Link from "next/link";
export default function Home() {
  return <>
    <section className="py-10 text-center">
      <div className="mx-auto mb-8 h-40 w-40 rounded-full bg-gradient-to-br from-blue-500 via-violet-600 to-transparent shadow-[0_0_80px_#6d28d977] motion-safe:animate-pulse" />
      <h1 className="text-4xl font-semibold sm:text-5xl">Meet the AI That Learns How You Decide.</h1>
      <p className="my-5 text-slate-300">Build a personal decision model based on your goals, preferences, and past choices.</p>
      <div className="flex justify-center gap-3"><Link className="btn" href="/assessment">Build My Mirror</Link><a className="ghost py-3" href="#how">See How It Works</a></div>
    </section>
    <section className="card"><h2 className="text-2xl">Not another chatbot.</h2><p className="mt-2 text-slate-300">Most AI tools try to answer for everyone. MIRROR AI learns your decision patterns and helps you understand what you are likely to choose.</p></section>
    <section id="how" className="grid grid-cols-2 gap-3 sm:grid-cols-4">{["Answer","Build","Challenge","Reflect"].map((s,i)=><div className="card" key={s}><small className="text-violet-300">0{i+1}</small><p>{s}</p></div>)}</section>
    <Link className="btn" href="/assessment">Build Your Decision DNA</Link>
  </>;
}
