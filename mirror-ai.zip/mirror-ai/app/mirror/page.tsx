"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
type Rec = { id: string; date: string; title: string; predicted: string; confidence: number; final: string; outcome: string; match?: boolean };
const read = (k: string, d: any) => { try { return JSON.parse(localStorage.getItem(k) ?? "") ?? d; } catch { return d; } };
const write = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
const show = (o: Record<string, unknown>) => Object.entries(o).map(([k, v]) => <div key={k}><b className="capitalize text-violet-300">{k.replace(/([A-Z])/g, " $1")}</b><p>{Array.isArray(v) ? v.join(" • ") : String(v)}{k === "confidence" && "%"}</p></div>);
export default function Mirror() {
  const [profile, setProfile] = useState<Record<string, number>>(), [mirror, setMirror] = useState(""), [decision, setDecision] = useState("");
  const [pred, setPred] = useState<any>(), [counter, setCounter] = useState<any>(), [history, setHistory] = useState<Rec[]>([]);
  const [busy, setBusy] = useState(false), [error, setError] = useState(""), [isDemo, setDemo] = useState(false);
  useEffect(() => { setProfile(read("dna", null)?.profile); setMirror(read("mirror", "")); setHistory(read("history", [])); }, []);
  const save = (h: Rec[]) => { setHistory(h); write("history", h); };
  const patch = (id: string, p: Partial<Rec>) => save(history.map(r => r.id === id ? { ...r, ...p } : r));
  async function run(mode: "predict" | "challenge") {
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/decide", { method: "POST", body: JSON.stringify({ mode, decision, mirror, profile: profile ?? { risk_tolerance: 50, planning: 70 }, prediction: pred?.predictedChoice }) });
      const j = await res.json(); if (!res.ok) throw new Error(j.error);
      setDemo(j.demo);
      if (mode === "challenge") setCounter(j.result);
      else { setPred(j.result); setCounter(null); save([{ id: crypto.randomUUID(), date: new Date().toLocaleDateString(), title: decision.slice(0, 80), predicted: j.result.predictedChoice, confidence: j.result.confidence, final: "", outcome: "" }, ...history]); }
    } catch (e) { setError(e instanceof Error ? e.message : "Network error. Try again."); }
    setBusy(false);
  }
  const rated = history.filter(r => r.match !== undefined);
  return <>
    {!profile && <p className="card">Using a demo profile. <Link className="underline" href="/assessment">Take the Decision DNA assessment</Link> to use yours.</p>}
    {isDemo && <p className="rounded-xl border border-amber-400 p-3 text-amber-300">DEMO MODE: AI is not running. Results are fixed examples.</p>}
    <details className="card"><summary>Update my Mirror</summary><textarea className="field mt-3" rows={5} maxLength={3000} placeholder="Goals, priorities, values, things you avoid, how you define success, risk preference. No sensitive personal details." value={mirror} onChange={e => { setMirror(e.target.value); write("mirror", e.target.value); }} /></details>
    <section className="card space-y-3"><label htmlFor="d" className="text-2xl">What decision are you facing?</label>
      <textarea id="d" className="field" rows={4} value={decision} onChange={e => { setDecision(e.target.value); setPred(null); setCounter(null); }} placeholder="I have an opportunity to start a new job, but it pays less initially." />
      <button className="btn" disabled={busy || decision.trim().length < 10} onClick={() => run("predict")}>{busy ? "Thinking…" : "Analyze My Decision"}</button>
      {error && <p role="alert" className="text-red-300">{error}</p>}</section>
    {pred && <section className="card space-y-3"><p className="text-sm text-slate-400">Based on the information you’ve provided, this is an estimate, not certainty.</p>{show(pred)}
      <button className="btn" disabled={busy} onClick={() => run("challenge")}>Challenge My Decision</button></section>}
    {counter && <section className="card space-y-3"><h2 className="text-xl">The other side</h2>{show(counter)}<button className="ghost" onClick={() => document.getElementById("d")?.focus()}>Re-evaluate: update the situation</button></section>}
    <h2 className="text-xl">History ({history.length})</h2>
    <p className="text-sm text-slate-400">Prediction matches: {rated.filter(r => r.match).length} of {rated.length} rated. Not a scientific measurement.</p>
    {history.map(r => <details key={r.id} className="card"><summary>{r.date}: {r.title}</summary><div className="mt-3 space-y-2">
      <p>{r.predicted} ({r.confidence}%)</p>
      <input className="field" placeholder="Your final choice" value={r.final} onChange={e => patch(r.id, { final: e.target.value })} />
      <input className="field" placeholder="Outcome (optional)" value={r.outcome} onChange={e => patch(r.id, { outcome: e.target.value })} />
      <div className="flex gap-2">{[true, false].map(m => <button key={String(m)} className={`ghost ${r.match === m ? "bg-violet-600" : ""}`} onClick={() => patch(r.id, { match: m })}>{m ? "Matched" : "Differed"}</button>)}
      <button className="ghost text-red-300" onClick={() => confirm("Delete this decision?") && save(history.filter(x => x.id !== r.id))}>Delete</button></div></div></details>)}
  </>;
}
