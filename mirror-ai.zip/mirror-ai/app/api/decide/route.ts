import { Input, runMirror } from "@/services/ai";
export async function POST(req: Request) {
  const parsed = Input.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Describe your decision in 10 to 2000 characters." }, { status: 400 });
  try { return Response.json(await runMirror(parsed.data)); }
  catch (e) { console.error(e); return Response.json({ error: "The analysis failed. Please try again." }, { status: 502 }); }
}
