export type Profile = Record<string, number>;
// [dimension, scenario, choices ordered from low to high on that dimension]
export const QUESTIONS: [string, string, string][] = [
["risk_tolerance","A friend invites you into a promising but unproven side project.","Decline|Help a few hours first|Commit fully"],
["risk_tolerance","You can pick a fixed bonus or a variable one that may be double or zero.","Fixed|Split if possible|Variable"],
["planning","You have a week off next month.","Decide on the day|Rough ideas|Detailed plan"],
["planning","A large task is due in three weeks.","Start near the deadline|Outline, then see|Schedule every step"],
["long_term_orientation","You receive unexpected money.","Enjoy it now|Save part|Invest in a future goal"],
["impulsiveness","Something you want is on sale for one hour.","Skip it|Check budget first|Buy now"],
["planning","Your free evening suddenly fills with requests.","Take them as they come|Pick the urgent one|Re-plan by priority"],
["long_term_orientation","A course takes a year before it pays off.","Pass|Try one month|Enroll"],
["goal_consistency","An attractive offer pulls you away from your main career goal.","Take it|Weigh both|Stay on course"],
["long_term_orientation","One job pays more now; another teaches more.","Higher pay|Negotiate|More learning"],
["social_influence","Everyone you know disagrees with your choice.","Proceed anyway|Reconsider a little|Change course"],
["social_influence","Choosing where the group eats, you usually…","Push your pick|Suggest options|Follow others"],
["persistence","Your third attempt at something fails.","Drop it|Pause and rethink|Try again with changes"],
["persistence","Progress has been invisible for a month.","Switch|Set a deadline|Keep going"],
["uncertainty_tolerance","You must decide with half the information.","Wait|Gather a bit more|Decide now"],
["uncertainty_tolerance","A trip has no confirmed itinerary.","Stressful|Manageable|Exciting"],
["impulsiveness","You get an irritating message.","Reply tomorrow|Draft, then wait|Reply instantly"],
["impulsiveness","A new hobby catches your eye.","Research for weeks|Borrow gear|Buy the full kit today"],
["goal_consistency","Halfway through a goal, a shinier idea appears.","Switch now|Note it for later review|Finish first"],
["risk_tolerance","A role with unclear duties but big upside opens.","Stay put|Ask questions first|Apply"]];
export function score(answers: number[]): Profile {
  const t: Record<string, number[]> = {};
  QUESTIONS.forEach(([d], i) => (t[d] ??= []).push(answers[i] * 50));
  return Object.fromEntries(Object.entries(t).map(([d, v]) => [d, Math.round(v.reduce((a, b) => a + b, 0) / v.length)]));
}
export function archetype(p: Profile) {
  const list: [string, number][] = [["THE BUILDER",p.persistence],["THE STRATEGIST",p.planning],["THE EXPLORER",p.risk_tolerance],["THE VISIONARY",p.long_term_orientation],["THE ADAPTER",p.uncertainty_tolerance],["THE ANALYST",100-p.impulsiveness]];
  return list.sort((a, b) => b[1] - a[1])[0][0];
}
