# MIRROR AI (core MVP)
## Local
Node 20+. `npm install`, `cp .env.example .env.local`, `npm run dev`, open http://localhost:3000
## Environment
- `OPENAI_API_KEY`: leave empty for Demo Mode (no login or credentials needed)
- `OPENAI_MODEL`: a model on your account that supports JSON output (required with a key)
## Vercel
Push to GitHub, import in Vercel, add the variables, deploy.
Before adding a real key to a public deployment, add auth and rate limiting to /api/decide.
## Data
Stored in the browser's localStorage. supabase/schema.sql is ready (run in the SQL editor) but not yet connected.
## Structure
app/ (pages, api/decide), lib/dna.ts (questions, scoring), services/ai/, supabase/
## Not yet built
Supabase Auth and persistence, dashboard, pricing, privacy page, sharing, shadcn/ui,
structured mirror model, AI profile generation and outcome analysis.
