-- Every table is private to its owner through Row Level Security.
create table profiles (id uuid primary key default gen_random_uuid(), user_id uuid not null unique default auth.uid() references auth.users on delete cascade, display_name text, created_at timestamptz default now());
create table decision_assessments (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users on delete cascade, answers jsonb not null, created_at timestamptz default now());
create table decision_profiles (like decision_assessments including defaults, scores jsonb not null, archetype text not null);
alter table decision_profiles drop column answers;
create table mirror_models (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users on delete cascade, model jsonb not null, created_at timestamptz default now());
create table decisions (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users on delete cascade, title text not null, prediction jsonb not null, confidence int check (confidence between 0 and 100), created_at timestamptz default now(), unique (id, user_id));
create table decision_outcomes (id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users on delete cascade, decision_id uuid not null, final_choice text, outcome text, matched boolean, foreign key (decision_id, user_id) references decisions (id, user_id) on delete cascade);
alter table decision_profiles add primary key (id), add foreign key (user_id) references auth.users on delete cascade;
do $$ declare t text; begin
 foreach t in array array['profiles','decision_assessments','decision_profiles','mirror_models','decisions','decision_outcomes'] loop
  execute format('alter table %I enable row level security', t);
  execute format('create policy own on %I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
 end loop; end $$;
